﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("EFCachingProvider")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MSIT")]
[assembly: AssemblyProduct("EFCachingProvider")]
[assembly: AssemblyCopyright("Copyright (c) Microsoft Corporation")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("e46871f4-3ce3-4983-b2fd-de265f47638b")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: InternalsVisibleTo("EFCachingProvider.Tests, PublicKey=002400000480000094000000060200000024000052534131000400000100010061573290409c1b42e87eb3b29b9f684521f750e2ebbce5bb78f86466affc680845f1afe4fe27af50c143373108a6e207ba2ca170bf28fcaff688229b10c65421d1f59528fbc0b62cfc87709a85c167ca1b2ce0f98e45f62f446af7d7ad1fef13f4689ac96695aff5d2be21019af93a7e68370f08e1391d14a2bc26e6f1e08e91")]

[assembly: CLSCompliant(true)]